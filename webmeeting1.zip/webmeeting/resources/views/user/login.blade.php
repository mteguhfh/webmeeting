<!DOCTYPE html>
<html lang="en" class="bg-dark">
<head>
  <meta charset="utf-8" />
  <title>BSS-OPS Web Meeting</title>
  <link rel="icon" type="image/png" href="{{ asset('images/logo.png') }}">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" /> 
  <link rel="stylesheet" href="{{ asset('css/bootstrap.css') }}" type="text/css" />
  <link rel="stylesheet" href="{{ asset('css/animate.css') }}" type="text/css" />
  <link rel="stylesheet" href="{{ asset('css/font-awesome.min.css') }}" type="text/css" />
  <link rel="stylesheet" href="{{ asset('css/font.css') }}" type="text/css" />
  <link rel="stylesheet" href="{{ asset('css/app.css') }}" type="text/css" />
  <link rel="stylesheet" href="{{ asset('css/style.css') }}">
  <!--[if lt IE 9]>
    <script src="js/ie/html5shiv.js"></script>
    <script src="js/ie/respond.min.js"></script>
    <script src="js/ie/excanvas.js"></script>
  <![endif]-->

</head>
<body class="">
  <section id="content" class="m-t-lg wrapper-md animated fadeInUp">    
    <div class="container aside-xxl">
      <!-- <a class="navbar-brand block" style="color:white" href="index.html"><strong>O&amp;M-BSS </strong> Weekly Meeting</a> -->
      <section class="panel panel-default bg-white m-t-lg" >
        <header class="panel-heading text-center">
          <h3><strong>BSS-OPS </strong> Web Meeting</h3>
        </header>

        {!! Form::open (['url' => 'user/auth', 'method' => 'post', 'class' => 'panel-body wrapper-lg' ]) !!}

          @if (Session::has('flash_message'))
            <div class="alert alert-success">{{ Session::get('flash_message') }}</div>
          @endif

          @if (Session::has('error_message'))
            <div class="alert alert-danger">{{ Session::get('error_message') }}</div>
          @endif

          <div class="form-group">
            <label class="control-label">Username</label>
            <input type="username" name="username" placeholder="Username" class="form-control input-lg">
          </div>
          <div class="form-group">
            <label class="control-label">Password</label>
            <input type="password" name="password" id="inputPassword" placeholder="Password" class="form-control input-lg">
          </div>
          
          <!-- <a href="#" class="pull-right m-t-xs"><small>Forgot password?</small></a> -->
          <button type="submit" class="btn btn-primary">Sign in</button>
        {!! Form::close() !!}

      </section>
    </div>
  </section>
  <!-- footer -->
  <footer id="footer">
    <div class="text-center padder">
      <p>
        <!-- <strong style="color:white;">O&amp;M-BSS &copy; 2015 All right reserved</strong> -->
      </p>
    </div>
  </footer>
  <!-- / footer -->
  
  <script src="{{ asset('js/jquery.min.js') }}"></script>
  <!-- Bootstrap -->
  <script src="{{ asset('js/bootstrap.js') }}"></script>
  <!-- App -->
  <script src="{{ asset('js/app.js') }}"></script> 
  <script src="{{ asset('js/slimscroll/jquery.slimscroll.min.js') }}"></script>
  <script src="{{ asset('js/app.plugin.js') }}"></script>

</body>
</html>