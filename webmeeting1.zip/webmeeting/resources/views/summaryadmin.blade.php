@extends('app')

@section('content')

<section class="scrollable">
              
      <div class="wrapper-lg">
        <h3 class="m-b-xs font-bold m-t-none">Weekly Meeting Summary</h3>
        <div class="text-muted text-sm">Welcome back, {{ Auth::user()->name }}</div>
      </div>
      
     <div class="col-md-8">
          <section class="panel panel-default">
          <header class="panel-heading font-bold">Issue section statistic</header>
            <div class="">
              <canvas style="padding:0 10px;" id="canvas" height="250" width="600"></canvas>
            </div>
         
          </section>
      </div>

      <div class="col-sm-4">

          <section class="panel panel-default">
            <header class="panel-heading font-bold">Issue status statistic</header>

                <div class="list-group bg-white">
                  <a href="{{ url('issue/status/open') }}" class="list-group-item">
                    <span class="pull-right">{{ $open }} Issues</span>
                    <i class="fa fa-refresh"></i>&nbsp; Open
                  </a>
               
                  <a href="{{ url('issue/status/closed') }}" class="list-group-item">
                    <span class="pull-right">{{ $closed }} Issues</span>
                    <i class="fa fa-check-circle fa-fw"></i>&nbsp; Closed
                  </a>

                  <a href="{{ url('issue/') }}" class="list-group-item">
                    <span class="pull-right">{{ $total }} Issues</span>
                    <i class="fa fa-archive fa-fw"></i>&nbsp; Total
                  </a>
                  
                  
                </div>
          </section>

  
</section>

<script>
  var randomScalingFactor = function(){ return Math.round(Math.random()*100)};

  var data = {
    labels : [ "Operation Support", "Sumatera-Kalbar-NU", "Ceskal-Bali-Nusra", "Sulawesi & Maluku", "Papua", "Management"],
    datasets : [
      
      {
        label: 'Section',
        fillColor: 'rgba(4,151,179,0.5)',
        highlightFill: 'rgba(0,163,124,0.5)',
        data : [ {{ $operation_support }}, {{ $sumatera_kalbar_nu }}, {{ $ceskal_bali_nusra }}, {{ $sulawesi_maluku }}, {{ $papua }}, {{ $management }},]
      }
    ]

  }
  
  window.onload = function(){
    var ctx = document.getElementById("canvas").getContext("2d");
    window.myBar = new Chart(ctx).HorizontalBar(data, {
      responsive : true,
    });
  }

  </script>




  </script>

@endsection