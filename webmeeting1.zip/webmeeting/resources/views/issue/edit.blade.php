@extends('app')

@section('content')

<section class="scrollable">
    <section class="bg-white panel-default">
    	<ul class="breadcrumb no-border no-radius b-b b-light pull-in" style="padding-left: 25px; margin-bottom:0;" >
            <li><a href="{{ url('/') }}"><i class="fa fa-bar-chart"></i> Summary</a></li>
            <li><a href="{{ url('issue')}}"> Issue</a></li>
            <li><a href="{{ url("issue/$issue->id/edit")}}"> Edit</a></li>
        </ul>

        <header class="panel-heading icon-mute">
        	<h4><i class="fa fa-file-o"></i>&nbsp;&nbsp;Update the Issue </h4>
        </header>

        @include('errors.notice')
       
        <div class="panel-body panel-default">

          {!! Form::model($issue, ['method' => 'PATCH',  'class' => 'form-horizontal', 'action' => ['IssueController@update', $issue->id]]) !!}

    		@include('issue.form')

          {!! Form::Close() !!}

        </div>
          
     </section>
 </section>


@stop