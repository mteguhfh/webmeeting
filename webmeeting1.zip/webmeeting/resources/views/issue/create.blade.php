@extends('app')

@section('content')

<section class="scrollable">
	<section class="bg-white panel-default">

		<ul class="breadcrumb no-border no-radius b-b b-light pull-in" style="padding-left: 25px; margin-bottom:0;" >
	        <li><a href="{{ url('/') }}"><i class="fa fa-bar-chart"></i> Summary</a></li>
	        <li><a href="{{ url('issue')}}">Issue</a></li>
	        <li><a href="{{ url('issue/create')}}">Create</a></li>
       	</ul>
       	
	    <header class="panel-heading icon-mute">
	    	<h4><i class="fa fa-file-o"></i>&nbsp;&nbsp;Add new Issue</h4>
	    </header>

	    @include('errors.notice')
	   
	    <div class="panel-body panel-default">

	      {!! Form::open(['url' => 'issue', 'method' => 'post', 'class' => 'form-horizontal']) !!}

			@include('issue.form')

	      {!! Form::close() !!}

	    </div>
	      
	 </section>

 </section>

@endsection