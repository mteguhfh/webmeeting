<div class="row">

    <div class="col-lg-8">

      @if(\Auth::user()->role == "operator" || \Auth::user()->role == "member")
        <div class="form-group @if($errors->has('section_id')) has-error @endif">
          {!! Form::label('section_id', 'Section / Dept', ['class' => 'col-lg-2 control-label']) !!}
          
          <div class="col-lg-10">
            {!! Form::select('section_id', $section, \Auth::user()->section_id, ['placeholder'  => 'Pick a Section / Dept...', 'class' => 'form-control m-b', 'disabled']); !!}
            @if ($errors->has('section_id'))
                <span class="help-block m-b-none">{{ $errors->first('section_id') }} </span> 
            @endif                                  
          </div>
        </div>
      @endif

      @if(\Auth::user()->role == "admin")
        <div class="form-group @if($errors->has('section_id')) has-error @endif">
          {!! Form::label('section_id', 'Section / Dept', ['class' => 'col-lg-2 control-label']) !!}
          
          <div class="col-lg-10">
            {!! Form::select('section_id', $section, null, ['placeholder'  => 'Pick a Section / Dept...', 'class' => 'form-control m-b']); !!}
            @if ($errors->has('section_id'))
                <span class="help-block m-b-none">{{ $errors->first('section_id') }} </span> 
            @endif                                  
          </div>
        </div>
      @endif

        <div class="form-group form-group @if($errors->has('issue_description')) has-error @endif">
          <label class="col-lg-2 control-label">Issue Description</label>
          <div class="col-lg-10">
              {!! Form::textarea('issue_description', null, ['class' => 'form-control', 'cols' => 20, 'rows' => 5, 'placeholder' => '']) !!}
                @if ($errors->has('topic'))
                 <span class="help-block m-b-none">{{ $errors->first('issue_description') }} </span>
                @endif 
          </div>
        </div>

        <div class="form-group form-group @if($errors->has('action_taken')) has-error @endif">
          <label class="col-lg-2 control-label">Action Taken</label>
          <div class="col-lg-10">
            {!! Form::textarea('action_taken', null, ['class' =>  'form-control', 'placeholder' => 'put description of the issue here', 'cols' => 20, 'rows' => 10 ]) !!}
       
              @if ($errors->has('action_taken'))
                <span class="help-block m-b-none">{{ $errors->first('action_taken') }} </span>
              @endif 
          </div>
        </div>


        <div class="form-group form-group @if($errors->has('pic')) has-error @endif">
          <label class="col-lg-2 control-label">PIC</label>
          <div class="col-lg-10">
          	{!! Form::select('section_list[]',  $section, null, ['style' => 'width:100%;', 'multiple', 'id' => 'adimas',]) !!}
              @if ($errors->has('action')) <span class="help-block m-b-none">{{ $errors->first('action') }} </span> @endif 
          </div>
        </div>

        <div class="form-group form-group @if($errors->has('issued_date')) has-error @endif">
          <label class="col-lg-2 control-label">Issued Date</label>
          <div class="col-lg-4">
            {!! Form::text('issued_date', null, [ 'class' => 'form-control datepicker-input', 'data-date-format' => 'yyyy-mm-dd', ] ) !!}
              @if ($errors->has('issued_date')) <span class="help-block m-b-none">{{ $errors->first('issued_date') }} </span> @endif 
          </div>
        </div>

        <div class="form-group form-group @if($errors->has('due_date')) has-error @endif">
          <label class="col-lg-2 control-label">Due Date</label>
          <div class="col-lg-4">
            {!! Form::text('due_date', null, [ 'class' => 'form-control datepicker-input', 'data-date-format' => 'yyyy-mm-dd',]) !!}
              @if ($errors->has('due_date')) <span class="help-block m-b-none">{{ $errors->first('due_date') }} </span> @endif 
          </div>
        </div>

        <div class="form-group form-group @if($errors->has('completion_date')) has-error @endif">
          <label class="col-lg-2 control-label">Completion Date</label>
          <div class="col-lg-4">
            {!! Form::text('completion_date', null, [ 'class' => 'form-control datepicker-input', 'data-date-format' => 'yyyy-mm-dd' , ]) !!}
              @if ($errors->has('completion_date')) <span class="help-block m-b-none">{{ $errors->first('completion_date') }} </span> @endif 
          </div>
        </div>

        <div class="form-group form-group @if($errors->has('status')) has-error @endif">
          <label class="col-lg-2 control-label">status</label>
          <div class="col-lg-4">
             {!! Form::select('status', [
          		'Open'          => 'Open',
          		'Closed'        => 'Closed',
          	], null, ['placeholder'  => 'Pick a Status...', 'class' => 'form-control m-b']); !!}
          	  @if ($errors->has('status')) <span class="help-block m-b-none">{{ $errors->first('status') }} </span> @endif 
          </div>
        </div>

        <div class="form-group  @if ($errors->has('update')) <span class="help-block m-b-none">{{ $errors->first('update') }} </span> @endif ">
          <label class="col-lg-2 control-label">Update</label>
          <div class="col-lg-10">

          {!! Form::textarea('action_update', null, ['class' => 'form-control', 'placeholder' => 'Action taken ...']) !!}
              @if ($errors->has('action_update')) <span class="help-block m-b-none">{{ $errors->first('action_updatef') }} </span> @endif 
          </div>
        </div>

        <div class="form-group">
          <div class="col-lg-offset-2 col-lg-10">
            <button class="btn btn-info btn-sm">Submit Data</button>
            <a href="{{ url('issue/') }}" class="btn btn-default btn-sm">Cancel</a>
          </div>
        </div>

  </div>

</div>


<script>
  $("#adimas").select2();
</script>
