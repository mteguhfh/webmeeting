<div class="table-responsive">
  <table class="table b-t b-light">
    <thead>
      <tr>
        <th width="20">No</th>
        <th width="120">Dept / Section</th>
        <th>Issue Description</th>
        <th width="200">Pic</th>
        <th width="120">Due Date</th>
        <th width="120">Completion Date</th>
        <th width="100">Aging</th>
        <th width="120">Status</th>
        <th width="250">Last Update</th>            
        <th width="120">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $i = 1; ?>
      @foreach($issues as $issue)
      <tr>
        <td>{{ $i++ }}</td>
        <td>{{ isset($issue->section->name) ? $issue->section->name : 'not set' }}</td>
        <td>{{ $issue->issue_description }}</td>
        
         <td>
           @if($issue->sections->count() != 0)
            <ul style="margin-left: -20px;">
              @foreach($issue->sections as $section)
                  <li style="line-height:1.5;">{{ $section->name }}</li>
              @endforeach
            </ul> 
            @else
              -
            @endif
        </td>

        <td>{{ \Carbon\Carbon::parse($issue->due_date)->toFormattedDateString() }}</td>
        <td> 
          @if(!empty($issue->completion_date) && $issue->completion_date != '0000-00-00')
            {{ \Carbon\Carbon::parse($issue->completion_date)->toFormattedDateString() }}
          @else
           Not Set
          @endif
        </td>
        <td> 
            @if(!empty($issue->completion_date) && $issue->completion_date != '0000-00-00')
              @if( \Carbon\Carbon::parse($issue->due_date)->diffInDays(\Carbon\Carbon::parse($issue->completion_date), false) < 7 )
                <p style="color:#00c7f7">
                  {{ \Carbon\Carbon::parse($issue->due_date)->diffInDays(\Carbon\Carbon::parse($issue->completion_date), false) }} Days
                </p>
              @else
                 <p class="text-danger">
                  {{ \Carbon\Carbon::parse($issue->due_date)->diffInDays(\Carbon\Carbon::parse($issue->completion_date), false) }} Days
                </p>
              @endif
             
            @else
              @if( \Carbon\Carbon::parse($issue->due_date)->diffInDays(\Carbon\Carbon::today(), false) < 7 )
                <p style="color:#00c7f7">
                  {{ \Carbon\Carbon::parse($issue->due_date)->diffInDays(\Carbon\Carbon::today(), false) }} Days
                </p>
              @else
                <p class="text-danger">
                  {{ \Carbon\Carbon::parse($issue->due_date)->diffInDays(\Carbon\Carbon::today(), false) }} Days
                </p>
              @endif

            @endif
       
        </td>
        <td>
          @if($issue->status == "Open")
            <p class="text-danger"><i class="fa fa-refresh fa-fw"></i> {{ $issue->status }}</p>
          @elseif($issue->status == "Closed")
            <p><i class="fa fa-check-circle fa-fw"></i> {{ $issue->status }}</p>
          @else
          @endif 
              
        </td>

        <td>
           @if(isset($issue->user_update))
             {{ $issue->user_update .'  '. $issue->updated_at->diffForHumans() }}
             @else
             {{ $issue->updated_at->diffForHumans() }} 
          @endif 
        </td>

       
        <td>
          <a class="btn btn-sm btn-icon btn-success" data-toggle="tooltip" data-original-title="Show Data" href="{{ URL::to('issue/' . $issue->id ) }}"><i class="fa fa-share-square-o fa-fw"></i></a>

          @if(\Auth::user()->role != "viewer")
             <a class="btn btn-sm btn-icon btn-warning" data-toggle="tooltip" data-original-title="Update Data" href="{{ URL::to('issue/' . $issue->id . '/edit') }}"><i class="fa fa-edit fa-fw"></i></a>
          @endif

          @if(\Auth::user()->section_id == 1 || \Auth::user()->role == "admin" )
            {!! Form::open(array('url' => 'issue/' . $issue->id, 'class' => 'form-horizotal', 'style' => 'display:inline;')) !!}
                {!! Form::hidden('_method', 'DELETE') !!}
                <button data-toggle="tooltip" data-original-title="Delete Data" onclick="return confirm('are you sure delete this data?')" class="btn btn-sm btn-icon btn-danger" ><i class="fa fa-trash-o fa-fw"></i></button>

            {!! Form::close() !!}
          @endif 
        </td> 
      </tr>
      @endforeach
  

    </tbody>
  </table>
</div>