@extends('app')

@section('content')

	<section class="bg-white panel-default scrollable">

	  <ul class="breadcrumb no-border no-radius b-b b-light pull-in" style="padding-left: 25px; margin-bottom:0;" >
        <li><a href="{{ url('/') }}"><i class="fa fa-bar-chart"></i> Summary</a></li>
        <li><a href="{{ url('issue')}}"> Issue</a></li>
      </ul>

	    <header class="panel-heading icon-mute"><h4><i class="fa fa-tasks"></i>&nbsp;&nbsp;List of dept issues</h4></header>


	     <div class="panel-body ">

	    	<div class="row wrapper">


	    <div class="table-responsive">
	  		<table class="table b-t b-light" style="font-size:140%;">
		      <thead>
		        <tr>
		          <th>Dept / Section</th>
		          <th class="text-danger text-center"><i class="fa fa-refresh fa-fw"></i> Open Issue</th>
		          <th class="text-success text-center"><i class="fa fa-check-circle fa-fw"></i> Closed Issue</th>
		          <th class="text-center"><i class="fa fa-archive fa-fw"></i> Total Issue</th>
		        </tr>
		      </thead>
		      <tbody>
		        <tr>
		          <td>Management</td>
		          <td class="text-center"><a href="/issue/status/open/section/1">{{ $manager_open }}</a></td>
		          <td class="text-center"><a href="/issue/status/closed/section/1">{{ $manager_closed }}</a></td>
		          <td class="text-center"><a href="issue/status/all/section/1">{{ $manager_total}}</a></td>
		        </tr>
		        
		        <tr>
		          <td>Papua</td>
		          <td class="text-center"><a href="issue/status/open/section/2">{{ $pp_open }}</a></td>
		          <td class="text-center"><a href="issue/status/closed/section/2">{{ $pp_closed }}</a></td>
		          <td class="text-center"><a href="issue/status/all/section/2">{{ $pp_total }}</a></td>
		        </tr>

		        <tr>
		          <td>Sulawesi-Maluku</td>
		          <td class="text-center"><a href="issue/status/open/section/3">{{ $sm_open }}</a></td>
		          <td class="text-center"><a href="issue/status/closed/section/3">{{ $sm_closed }}</a></td>
		          <td class="text-center"><a href="issue/status/all/section/3">{{ $sm_total }}</a></td>
		        </tr>
		        <tr>
		          <td>Ceskal-Bali-Nusra</td>
		          <td class="text-center"><a href="issue/status/open/section/4">{{ $cbn_open }}</a></td>
		          <td class="text-center"><a href="issue/status/closed/section/4">{{ $cbn_closed }}</a></td>
		          <td class="text-center"><a href="issue/status/all/section/4">{{ $cbn_total }}</a></td>
		        </tr>
		        <tr>
		          <td>Sumatera-Kalbar-NU</td>
		          <td class="text-center"><a href="issue/status/open/section/5">{{ $skn_open }}</a></td>
		          <td class="text-center"><a href="issue/status/closed/section/5">{{ $skn_closed }}</a></td>
		          <td class="text-center"><a href="issue/status/all/section/5">{{ $skn_total }}</a></td>
		        </tr>
		        <tr>
		          <td>Operation Support</td>
		          <td class="text-center"><a href="issue/status/open/section/6">{{ $os_open }}</a></td>
		          <td class="text-center"><a href="issue/status/closed/section/6">{{ $os_closed }}</a></td>
		          <td class="text-center"><a href="issue/status/all/section/6">{{ $os_total }}</a></td>
		        </tr>
		      </tbody>
		      <tfoot>
		      	<tr>
		          <th>Total</th>
		          <th class="text-center"><a href="/issue/status/open">{{ $open_total }}</a></th>
		          <th class="text-center"><a href="/issue/status/closed">{{ $close_total }}</a></th>
		          <th class="text-center"><a href="/issue/manager">{{ $all_total }}</a></th>
		      </tfoot>
		    </table>
		 </div>

		 </div>
		 </div>


	</section>

@stop