@extends('app')

@section('content')

<div class="scrollable">

	<section class="bg-white panel-default">
       <ul class="breadcrumb no-border no-radius b-b b-light pull-in" style="padding-left: 25px; margin-bottom:0;" >
        <li><a href="{{ url('/') }}"><i class="fa fa-bar-chart"></i> Summary</a></li>
        <li><a href="{{ url('issue')}}"> Issue</a></li>
        <li><a href="{{ url("issue/$issue->id")}}"> Show</a></li>
       </ul>

	     <header class="panel-heading icon-mute"><h4><i class="fa fa-globe"></i>&nbsp;&nbsp; Detailed issue<br> 
       <small class="text-mute">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
       @if(isset($issue->user_update))
       last updated by, {{ $issue->user_update .'  '. $issue->updated_at->diffForHumans() }}
       @else
       last updated, {{ $issue->updated_at->diffForHumans() }} 
       @endif 

        
        </small></h4>
      </header>

	    @include('errors.notice')
	   

	    <div class="panel-body panel-default">

          <div class="row">
            <div class="col-lg-3">
              <strong>Section / Dept :</strong> 
              <h4>{{ $issue->section->name }}</h4>                    

              <strong>Status :</strong> 
            
              @if($issue->status == "Open")
                <h4 class="text-danger"><i class="fa fa-refresh fa-fw"></i> {{ $issue->status }}</h4>
              @elseif($issue->status == "Closed")
                <h4><i class="fa fa-check-circle fa-fw"></i> {{ $issue->status }}</h4>
              @else
              @endif 
            
             
            </div>
            <div class="col-lg-3">

              <!-- <strong>Issued Date :</strong>    
              <h4>{{ \Carbon\Carbon::parse($issue->issued_date)->toFormattedDateString() }} </h4> -->
              
              <strong>Due Date :</strong>    
              <h4>{{ \Carbon\Carbon::parse($issue->due_date)->toFormattedDateString() }} </h4>
         

              <strong>Completion Date :</strong>
              <h4>
                 @if(!empty($issue->completion_date) && $issue->completion_date != '0000-00-00')
                  {{ \Carbon\Carbon::parse($issue->completion_date)->toFormattedDateString() }}
                @else
                 Not Set
                @endif
              </h4>

               
            </div>
            <div class="col-lg-4">

              <strong>Aging :</strong>
              @if(!empty($issue->completion_date) && $issue->completion_date != '0000-00-00')
                @if( \Carbon\Carbon::parse($issue->due_date)->diffInDays(\Carbon\Carbon::parse($issue->completion_date), false) < 7 )
                  <h4 style="color:#00c7f7">
                    {{ \Carbon\Carbon::parse($issue->due_date)->diffInDays(\Carbon\Carbon::parse($issue->completion_date), false) }} Days
                  </h4>
                @else
                   <h4 class="text-danger">
                    {{ \Carbon\Carbon::parse($issue->due_date)->diffInDays(\Carbon\Carbon::parse($issue->completion_date), false) }} Days
                  </h4>
                @endif
               
              @else
                @if( \Carbon\Carbon::parse($issue->due_date)->diffInDays(\Carbon\Carbon::today(), false) < 7 )
                  <h4 style="color:#00c7f7">
                    {{ \Carbon\Carbon::parse($issue->due_date)->diffInDays(\Carbon\Carbon::today(), false) }} Days
                  </h4>
                @else
                   <h4 class="text-danger">
                    {{ \Carbon\Carbon::parse($issue->due_date)->diffInDays(\Carbon\Carbon::today(), false) }} Days
                  </h4>
                @endif

              @endif

              <strong>Pic :</strong> 
              <h4>
                @if($sections->count() != 0)
                <ul style="margin-left: -20px;">
                  @foreach($sections as $section)
                      <li style="line-height:1.5;">{{ $section->name }}</li>
                  @endforeach
                </ul> 
                @else
                  Not Set
                @endif
              </h4>  
            </div>


          </div>

          <hr>

          <div class="row">
            <div class="col-lg-9">
                <strong>Issue Description :</strong>
                <br>
                <h3 style="line-height:1.5;">{!! nl2br($issue->issue_description) !!}</h3>
                <br>

                <strong>Action Taken :</strong>
                <br>
                <h3 style="line-height:1.5;">{!! nl2br($issue->action_taken) !!}</h3>
                <br>

               <strong>Update :</strong>
               <br>
               <h3 style="line-height:1.5;">{!! nl2br($issue->action_update) !!}</h3>

            </div>
          </div>

          <hr>

          @if(Auth::user()->role != "viewer")
            <a class="btn btn-warning" href="{{ URL::to('issue/' . $issue->id . '/edit') }}"><i class="fa fa-edit fa-fw"></i> update data</a>
          @endif

               
          @if(\Auth::user()->role == "admin" || \Auth::user()->section_id == 1)

              {!! Form::open(array('url' => 'issue/' . $issue->id, 'class' => 'form-horizotal', 'style' => 'display:inline;')) !!}
                  {!! Form::hidden('_method', 'DELETE') !!}
                  <button onclick="return confirm('are you sure delete this data?')" class="btn btn-danger"><i class="fa fa-trash-o fa-fw"></i> delete data</button>
              {!! Form::close() !!}
          
              <a class="btn btn-blue" href="{{ URL::to('issue/' . 'status/open/section/'. $issue->section_id ) }}"><i class="fa fa-list fa-fw"></i> back to section</a>

          @endif

	    </div>

     

      
     
	</section>
</div>

@stop