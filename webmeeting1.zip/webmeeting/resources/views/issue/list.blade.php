@extends('app')

@section('content')

	<section class="bg-white panel-default scrollable">

      <ul class="breadcrumb no-border no-radius b-b b-light pull-in" style="padding-left: 25px; margin-bottom:0;" >
        <li><a href="{{ url('/') }}"><i class="fa fa-bar-chart"></i> Summary</a></li>
        <li><a href="{{ url('issue')}}"> Issue</a></li>
      </ul>

	    <header class="panel-heading icon-mute">
        <h4><i class="fa fa-tasks"></i>&nbsp;&nbsp; List of
  
        @if($id == 1)
        Management
        @elseif($id == 2)
        Sales
        @elseif($id == 3)
        Product &amp; Commercial
        @elseif($id == 4)
        Steam Power Plant
        @elseif($id == 5)
        Gas Power Plant
        @elseif($id == 6)
        Reciprocating
        @elseif($id == 7)
        Equipment Management
        @elseif($id == 8)
        Business Support &amp; Services
        @elseif($id == 9)
        General
        @endif
        issues</h4>
      </header>

	    @include('errors.notice')
	   

	    <div class="panel-body ">

	    	<div class="row wrapper">

                  <div class="col-lg-2 m-15-left">
                     <a href="{{ url('issue/create') }}" class="btn btn-s-md btn-default form-control"><i class="fa fa-file"></i>&nbsp; Create new issue</a>
                  </div>
               
                  <div class="col-lg-3 pull-right">
                    {!! Form::open(['url' => 'issue/search', 'method' => 'post' ]) !!}
                      <div class="input-group">
                        <input type="text" name="search" class="input-sm form-control" placeholder="Search">
                        <span class="input-group-btn">
                          <button class="btn btn-sm btn-default" type="submit">Go!</button>
                        </span>
                      </div>
                     
                    {!! Form::close() !!}
                  </div>


            </div>


              @include('issue.table')

                <footer class="panel-footer">
                  <div class="row">
                    
                    <div class="col-sm-offset-4 col-sm-4 text-center">
                    	<div class="pagination">
                      		<small class="text-muted inline m-t-sm m-b-sm">showing {{ $issues->count() }} of {{ $issues->total() }} items</small>
                      	</div>
                    </div>
                    <div class="col-sm-4 text-right text-center-xs">                
                         
                      	{!! $issues->render() !!}
                   
                  </div>
                </footer>



	    </div>
	</section>

@stop