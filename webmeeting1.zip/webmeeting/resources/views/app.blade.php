<!DOCTYPE html>
<html lang="en" class="app">
<head>
  <meta charset="utf-8" />
  <title>O&amp;M-BSS Head Meeting</title>
  <link rel="icon" type="image/png" href="{{ asset('images/logo.png') }}">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" /> 
  <link rel="stylesheet" href="{{ asset('css/bootstrap.css') }}" type="text/css" />
  <link rel="stylesheet" href="{{ asset('css/animate.css') }}" type="text/css" />
  <link rel="stylesheet" href="{{ asset('css/font-awesome.min.css') }}" type="text/css" />
  <link rel="stylesheet" href="{{ asset('css/font.css') }}" type="text/css" />
  <link rel="stylesheet" href="{{ asset('js/datepicker/datepicker.css') }}" type="text/css" >
  <link rel="stylesheet" href="{{ asset('css/app.css') }}" type="text/css" />


  <!-- rel javascript -->

  <script src="{{ asset('js/jquery.min.js') }}"></script>

  <script src="{{ asset('js/select2/select2.min.js') }}"></script>
  <link rel="stylesheet" href="{{ asset('js/select2/select2.css') }}" type="text/css" /> 
  <link rel="stylesheet" href="{{ asset('js/select2/theme.css') }}" type="text/css" /> 


  <!--[if lt IE 9]>
    <script src="{{ asset('js/ie/html5shiv.js') }}"></script>
    <script src="{{ asset('js/ie/respond.min.js') }}"></script>
    <script src="{{ asset('js/ie/excanvas.js') }}"></script>
  <![endif]-->

  <style>
   .alerts{
    padding: 15px;
    margin-bottom: 20px;
  }

  .textarea {
    resize: none;
  }

  .m-15-left{
    margin-left: -15px;
  }

  .m-55-right{
    margin-right: -55px;
  }

  .btn-blue {
    color: #fff !important;
    background-color: rgb(52, 152, 219);
    border-color: rgb(52, 152, 219);
  }

  .pagination > .active > a,
  .pagination > .active > span,
  .pagination > .active > a:hover,
  .pagination > .active > span:hover,
  .pagination > .active > a:focus,
  .pagination > .active > span:focus {
    z-index: 2;
    color: #fff;
    cursor: default;
    background-color: rgb(52, 152, 219);
    border-color: rgb(52, 152, 219);
  }

  </style>

  <script type="text/javascript">
    $(document).ready(function(){
        $('[data-toggle="tooltip"]').tooltip({
            placement : 'top'
        });
    });
  </script>

</head>
<body class="">
  <section class="vbox">
    <header class="bg-dark dk header navbar navbar-fixed-top-xs">
      <div class="navbar-header aside-md">
        <a class="btn btn-link visible-xs" data-toggle="class:nav-off-screen,open" data-target="#nav,html">
          <i class="fa fa-bars"></i>
        </a>
        <a href="#" class="navbar-brand" data-toggle="fullscreen"><img src="{{ asset('images/logo.png') }}" class="m-r-sm">Weekly Meeting</a>
        <a class="btn btn-link visible-xs" data-toggle="dropdown" data-target=".nav-user">
          <i class="fa fa-cog"></i>
        </a>
      </div>
      
      <ul class="nav navbar-nav navbar-right m-n hidden-xs nav-user">
        
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <!-- <span class="thumb-sm avatar pull-left">
              <img src="{{ asset('images/avatar.jpg') }}">
            </span> -->
            <span class="thumb-sm avatar pull-left">
              <img src="{{ "http://www.gravatar.com/avatar/" . md5( strtolower( trim( \Auth::user()->email ) ) ) . "&s=" . "500" }}">
            </span>

            &nbsp;  {{ Auth::user()->name }} <b class="caret"></b>
          </a>
          <ul class="dropdown-menu animated fadeInRight">
            <span class="arrow top"></span>
            <li>
              <a href="{{ url('/user/editprofile/')}}">Change Password</a>
            </li> 
            <li class="divider"></li>
            <li>
              <a href="{{ url('logout') }}">Logout</a>
            </li>
          </ul>
        </li>
      </ul>      
    </header>
    <section>
      <section class="hbox stretch">
        <!-- .aside -->
        <aside class="bg-dark lter b-r aside-md hidden-print hidden-xs" id="nav">          
          <section class="vbox">
           
            <section class="w-f scrollable">
              <div class="slim-scroll" data-height="auto" data-disable-fade-out="true" data-distance="0" data-size="5px" data-color="#333333">
                
                <!-- nav -->
                <nav class="nav-primary hidden-xs">
                  <ul class="nav">
                    <li> <!-- dashboard -->
                      <a href="{{ url('summary')}}"  >
                        <i class="fa fa-bar-chart-o icon">
                          <b class="bg-danger"></b>
                        </i>
                        <span class="pull-right">
                         
                        </span>
                        <span>Summary</span>
                      </a>
                    </li>
                    @if(\Auth::user()->role != "member")
                      <li >
                        <a href="{{ url('issue/create') }}"  >
                          <i class="fa fa-pencil icon">
                            <b class="bg-warning"></b>
                          </i>
                          <span class="pull-right">
                          </span>
                          <span>Add new issue</span>
                        </a>
                      </li>
                    @endif

                    <!-- konon mitosnya ga dipake tp entah kalo berubah lg -->

                    <!-- @if(\Auth::user()->role == "manager" || \Auth::user()->role == "admin" )
                      <li >
                        <a href="{{ url('issue/priority/list') }}"  >
                          <i class="fa fa-exclamation icon">
                            <b class="" style="background-color:#9b59b6;" ></b>
                          </i>
                          <span class="pull-right">
                          </span>
                          <span>Priority Issue</span>
                        </a>
                      </li>
                    @endif -->

                    <li >
                      <a href="#nav"  >
                        <i class="fa fa-map-marker icon">
                          <b class="btn-twitter"></b>
                        </i>
                        <span class="pull-right">
                          <i class="fa fa-angle-down text"></i>
                          <i class="fa fa-angle-up text-active"></i>
                        </span>
                        <span>Issue status</span>
                      </a>
                      <ul class="nav lt">
                        <li >
                          <a href="{{ url('issue/status/open') }}" >                                                        
                            <i class="fa fa-angle-right"></i>
                            <span>Open</span>
                          </a>
                        </li>
                        <li >

                        </li>

                         <li >
                          <a href="{{ url('issue/status/closed')}}" >                                                        
                            <i class="fa fa-angle-right"></i>
                            <span>Closed</span>
                          </a>
                        </li>
                     
                       
                      </ul>
                    </li>

                    <li >
                      <a href="{{ url('issue') }}" >
                        <i class="fa fa-file-text icon">
                          <b class="bg-success"></b>
                        </i>
                        <span class="pull-right">
                        </span>
                        <span>MOM Dept</span>
                      </a>
                    </li>

                    <!-- < li >
                      <a href="#nav"  >
                        <i class="fa fa-file-text icon">
                          <b class="bg-success"></b>
                        </i>
                        <span class="pull-right">
                          <i class="fa fa-angle-down text"></i>
                          <i class="fa fa-angle-up text-active"></i>
                        </span>
                        <span>MOM Dept</span>
                      </a>
                      <ul class="nav lt">
                        <li >
                          <a href="{{ url('issue') }}" >                                                        
                            <i class="fa fa-angle-right"></i>
                            <span>All</span>
                          </a>
                        </li>
                        <li >
                    
                        <li >
                          <a href="{{ url('issue/section/1')}}" >                                                        
                            <i class="fa fa-angle-right"></i>
                            <span>Management</span>
                          </a>
                        </li>
                    
                        <li >
                          <a href="{{ url('issue/section/2') }}" >                                                        
                            <i class="fa fa-angle-right"></i>
                            <span>Sales</span>
                          </a>
                        </li>
                    
                        <li >
                          <a href="{{ url('issue/section/3') }}" >                                                        
                            <i class="fa fa-angle-right"></i>
                            <span>Product &amp; Commercial</span>
                          </a>
                        </li>
                    
                        <li >
                          <a href="{{ url('issue/section/4') }}" >                                                        
                            <i class="fa fa-angle-right"></i>
                            <span>Steam Power Plant</span>
                          </a>
                        </li>
                    
                         <li >
                          <a href="{{ url('issue/section/5') }}" >                                                        
                            <i class="fa fa-angle-right"></i>
                            <span>Gas Power Plant</span>
                          </a>
                        </li>
                    
                        <li >
                          <a href="{{ url('issue/section/6')}}" >                                                        
                            <i class="fa fa-angle-right"></i>
                            <span>Reciprocating</span>
                          </a>
                        </li>
                    
                         <li >
                          <a href="{{ url('issue/section/7')}}" >                                                        
                            <i class="fa fa-angle-right"></i>
                            <span>Equipment Management</span>
                          </a>
                        </li>
                    
                         <li >
                          <a href="{{ url('issue/section/8')}}" >                                                        
                            <i class="fa fa-angle-right"></i>
                            <span>Business Support &amp; Services</span>
                          </a>
                        </li>
                    
                        <li >
                          <a href="{{ url('issue/section/9') }}" >                                                        
                            <i class="fa fa-angle-right"></i>
                            <span>General</span>
                          </a>
                        </li>
                       
                      </ul>
                    </li> -->

                    <li >
                      <a href="{{ url('issue/export') }}"  >
                        <i class="fa fa-print icon">
                          <b class="btn-facebook"></b>
                        </i>
                        <span class="pull-right">
                        </span>
                        <span>Export data</span>
                      </a>
                    </li>
                    
                    <li >
                    @if(Auth::user()->role === "admin")
                      <a href="{{ url('user') }}"  >
                        <i class="fa fa-users icon">
                          <b class="bg-info dker"></b>
                        </i>
                        <span>User </span>
                      </a>
                    @endif
                    </li>
                   
                  </ul>
                </nav>
                <!-- / nav -->
              </div>
            </section>

            <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen, open" data-target="#nav,html"></a>
            
            <footer class="footer lt hidden-xs b-t b-dark">
              <a href="#nav" data-toggle="class:nav-xs" class="pull-right btn btn-sm btn-dark btn-icon">
                <i class="fa fa-angle-left text"></i>
                <i class="fa fa-angle-right text-active"></i>
              </a>
            </footer>
          </section>
        </aside>
        <!-- /.aside -->
        <section id="content">
           <section class="vbox">          
              
                @yield('content') 
             
            </section>
        </section>
  
      </section>
      <!-- /.h-strectj -->
    </section>
  </section>

  <!--  date picker -->
  <script src="{{ asset('js/datepicker/bootstrap-datepicker.js') }}"></script>

  <script>
    $('.datepicker-input').datepicker()
  </script>

  <!-- Bootstrap -->
  <script src="{{ asset('js/bootstrap.js') }}"></script>

  <script src="{{ asset('js/Chart.js') }}"></script>
  <script src="{{ asset('js/Chart.HorizontalBar.js') }}"></script>
  <!-- App -->
  <script src="{{ asset('js/app.js') }}"></script> 
  <script src="{{ asset('js/slimscroll/jquery.slimscroll.min.js') }}"></script>
  <script src="{{ asset('js/app.plugin.js') }}"></script>

</body>
</html>